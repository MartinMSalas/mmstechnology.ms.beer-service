package com.mmstechnology.ms.beer_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
